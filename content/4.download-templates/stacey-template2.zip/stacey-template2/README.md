# Stacey - Template 2

This is the second stacey template.  
You can see it running at <http://template2.staceyapp.com> or download it manually from <http://staceyapp.com/download-templates/>

## Installation

Replace the `content`, `public` & `templates` folders from the default stacey installation with the folders from this repo.

## Read More

See <http://staceyapp.com> for more detailed usage information.  
Or the main stacey repo at <http://github.com/kolber/stacey>

## Copyright/License

Copyright (c) 2009 Anthony Kolber. See `LICENSE` for details.